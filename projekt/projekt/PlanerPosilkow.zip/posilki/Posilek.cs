﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanerPosilkow
{
    public class Posilek
    {
        // Właściwości
        public string Nazwa { get; set; } // Nazwa posiłku
        public double Kalorie { get; set; } // Liczba kalorii
        public DateTime Data { get; set; } // Data posiłku

        // Konstruktor domyślny
        public Posilek()
        {
            Nazwa = "Nieznany posiłek";
            Kalorie = 0;
            Data = DateTime.Now;
        }

        // Konstruktor z parametrami
        public Posilek(string nazwa, double kalorie, DateTime data)
        {
            Nazwa = nazwa;
            Kalorie = kalorie;
            Data = data;
        }

        // Metoda wirtualna do wyświetlania informacji o posiłku
        public virtual void WyswietlInformacje()
        {
            Console.WriteLine($"Nazwa: {Nazwa}, Kalorie: {Kalorie}, Data: {Data.ToShortDateString()}");
        }

        // Przeciążenie metody ToString()
        public override string ToString()
        {
            return $"{Nazwa} ({Kalorie} kcal) - {Data.ToShortDateString()}";
        }
    }
}
