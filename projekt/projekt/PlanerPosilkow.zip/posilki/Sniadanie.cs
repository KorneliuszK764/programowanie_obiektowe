﻿using System;

namespace PlanerPosilkow
{
    public class Sniadanie : Posilek
    {
        public Sniadanie(string nazwa, double kalorie, DateTime data) : base(nazwa, kalorie, data) { }

        public override void WyswietlInformacje()
        {
            Console.WriteLine($"Śniadanie: {Nazwa}, Kalorie: {Kalorie}, Data: {Data.ToShortDateString()}");
        }
    }
}
