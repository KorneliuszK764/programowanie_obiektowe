﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanerPosilkow
{
    public class Obiad : Posilek
    {
        public Obiad(string nazwa, double kalorie, DateTime data) : base(nazwa, kalorie, data) { }

        public override void WyswietlInformacje()
        {
            Console.WriteLine($"Obiad: {Nazwa}, Kalorie: {Kalorie}, Data: {Data.ToShortDateString()}");
        }
    }
}
