﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanerPosilkow
{
    public class Kolacja : Posilek
    {
        public Kolacja(string nazwa, double kalorie, DateTime data) : base(nazwa, kalorie, data) { }

        public override void WyswietlInformacje()
        {
            Console.WriteLine($"Kolacja: {Nazwa}, Kalorie: {Kalorie}, Data: {Data.ToShortDateString()}");
        }
    }
}
