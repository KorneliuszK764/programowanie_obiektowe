﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace PlanerPosilkow
{
    public partial class Form1: Form
    {
        private PlanPosilkow planPosilkow;
        private BazaDanych bazaDanych;
        private bool trybEdycji;
        private Posilek edytowanyPosilek;


        public Form1(PlanPosilkow planPosilkow, BazaDanych bazaDanych)
        {
            InitializeComponent();
            this.planPosilkow = planPosilkow;
            this.bazaDanych = bazaDanych;
            this.trybEdycji = false;
        }

        public void AktualizujListe()
        {
            // Czyścimy ListBox przed dodaniem nowych danych
            listBox1.Items.Clear();

            // Sortujemy posiłki po dacie rosnąco (od najstarszej do najnowszej)
            var posilkiPosortowane = planPosilkow.Posilki.OrderBy(p => p.Data).ToList();

            // Iterujemy po posiłkach i dodajemy je do ListBox w formie tekstu
            foreach (var posilek in posilkiPosortowane)
            {

                string typPosilku = "Posiłek";
                if (posilek.GetType().Name.Equals("Sniadanie"))
                {
                    typPosilku = "Śniadanie";
                }
                else if (posilek.GetType().Name.Equals("Obiad"))
                {
                    typPosilku = "Obiad";
                }
                else if (posilek.GetType().Name.Equals("Przekaska"))
                {
                    typPosilku = "Przekąska";
                }
                else if (posilek.GetType().Name.Equals("Kolacja"))
                {
                    typPosilku = "Kolacja";
                }


                string posilekInfo =
                    $"{posilek.Data.ToString("dd-MM-yyyy HH:mm:ss")}" +
                    $"   |   " +
                    $"{posilek.Nazwa} - {typPosilku} ({posilek.Kalorie} kcal)";
                listBox1.Items.Add(posilekInfo);
            }
        }

        public void WlaczTrybEdycji(Posilek posilek)
        {
            edytowanyPosilek = posilek;

            textBox1.Text = edytowanyPosilek.Nazwa;
            textBox2.Text = edytowanyPosilek.Kalorie.ToString();
            dateTimePicker1.Value = edytowanyPosilek.Data;

            comboBox1.Enabled = false;

            // Sprawdzamy typ posiłku i ustawiamy odpowiednią wartość w ComboBox
            if (edytowanyPosilek.GetType().Name.Equals("Sniadanie"))
            {
                comboBox1.SelectedItem = "Śniadanie";
            }
            else if (edytowanyPosilek.GetType().Name.Equals("Obiad"))
            {
                comboBox1.SelectedItem = "Obiad";
            }
            else if (edytowanyPosilek.GetType().Name.Equals("Przekaska"))
            {
                comboBox1.SelectedItem = "Przekąska";
            }
            else if (edytowanyPosilek.GetType().Name.Equals("Kolacja"))
            {
                comboBox1.SelectedItem = "Kolacja";
            }

            button1.Visible = false;
            button3.Visible = true;
            button4.Visible = true;
            this.trybEdycji = true;
        }

        public void WylaczTrybEdycji()
        {
            comboBox1.SelectedItem = null;
            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Value = DateTime.Now;

            comboBox1.Enabled = true;

            button1.Visible = true;
            button3.Visible = false;
            button4.Visible = false;
            this.trybEdycji = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AktualizujListe();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            String nazwa = textBox1.Text;
            String rawKalorie = textBox2.Text;
            DateTime data = dateTimePicker1.Value;

            // Przycina sekund i milisekund w datach (ignoruje sekundy i milisekundy)
            data = data.AddMilliseconds(-data.Millisecond);

            if (comboBox1.Text.Equals("") || nazwa.Equals("") || rawKalorie.Equals(""))
            {
                MessageBox.Show("Uzupełnij dane!");
                return;
            }

            Double kalorie;
            if (!Double.TryParse(rawKalorie, out kalorie))
            {
                MessageBox.Show("Wprowadź prawidłową liczbę kalorii!");
                return;
            }

            foreach (var posilek in planPosilkow.Posilki)
            {
                if (posilek.Data == data)  // Porównujemy daty i godziny
                {
                    MessageBox.Show("Posiłek z tą datą i godziną już istnieje");
                    return;
                }
            }

            if (comboBox1.Text.Equals("Śniadanie"))
            {
                Sniadanie sniadanie = new Sniadanie(nazwa, kalorie, data);
                planPosilkow.DodajPosilek(sniadanie);
                bazaDanych.ZapiszDane();
            }
            else if (comboBox1.Text.Equals("Obiad"))
            {
                Obiad obiad = new Obiad(nazwa, kalorie, data);
                planPosilkow.DodajPosilek(obiad);
                bazaDanych.ZapiszDane();
            }
            else if (comboBox1.Text.Equals("Przekąska"))
            {
                Przekaska przekaska = new Przekaska(nazwa, kalorie, data);
                planPosilkow.DodajPosilek(przekaska);
                bazaDanych.ZapiszDane();
            }
            else if (comboBox1.Text.Equals("Kolacja"))
            {
                Kolacja kolacja = new Kolacja(nazwa, kalorie, data);
                planPosilkow.DodajPosilek(kolacja);
                bazaDanych.ZapiszDane();
            }

            comboBox1.SelectedItem = null;
            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Value = DateTime.Now;

            AktualizujListe();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                // Pobierz wybrany element z ListBox
                string wybranyPosilekInfo = listBox1.SelectedItem.ToString();

                // Zakładając, że format w ListBox to: "yyyy-MM-dd HH:mm   |   Nazwa - Typ - Kalorie kcal"
                // Rozdzielamy tekst na datę i inne informacje
                string[] posilekParts = wybranyPosilekInfo.Split(new string[] { "   |   " }, StringSplitOptions.None);

                if (posilekParts.Length > 1)
                {
                    // Parsowanie daty
                    DateTime dataPosilku = DateTime.ParseExact(posilekParts[0], "dd-MM-yyyy HH:mm:ss", null);

                    // Przycina sekund i milisekund w datach (ignoruje sekundy i milisekundy)
                    dataPosilku = dataPosilku.AddMilliseconds(-dataPosilku.Millisecond);

                    // Szukamy posiłku na podstawie przyciętej daty i godziny (bez sekund i milisekund)
                    Posilek posilek = planPosilkow.Posilki.FirstOrDefault(p =>
                        p.Data.AddMilliseconds(-p.Data.Millisecond).ToString().Equals(dataPosilku.ToString()));

                    if (posilek != null)
                    {
                        // Jeśli posiłek został znaleziony, przechodzimy do trybu edycji
                        WlaczTrybEdycji(posilek);
                    }
                }
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            if(edytowanyPosilek != null)
            {
                planPosilkow.UsunPosilek(edytowanyPosilek.Data);
                AktualizujListe();
                bazaDanych.ZapiszDane();

                WylaczTrybEdycji();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (edytowanyPosilek != null)
            {
                Double kalorie;
                if (!Double.TryParse(textBox2.Text, out kalorie))
                {
                    MessageBox.Show("Wprowadź prawidłową liczbę kalorii!");
                    return;
                }

                // Przycina sekund i milisekund w datach (ignoruje sekundy i milisekundy)
                DateTime data = edytowanyPosilek.Data
                    .AddMilliseconds(-edytowanyPosilek.Data.Millisecond);

                planPosilkow.AktualizujPosilek(data, textBox1.Text, kalorie, dateTimePicker1.Value);
                AktualizujListe();
                bazaDanych.ZapiszDane();

                WylaczTrybEdycji();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button2.Enabled = true;
        }
    }
}
