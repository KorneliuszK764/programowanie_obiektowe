﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanerPosilkow
{
    public class PlanPosilkow
    {
        public List<Posilek> Posilki { get; private set; }

        public PlanPosilkow()
        {
            Posilki = new List<Posilek>();
        }

        public void DodajPosilek(Posilek posilek)
        {
            if (posilek == null)
            {
                throw new ArgumentNullException(nameof(posilek), "Posiłek nie może być null.");
            }
            Posilki.Add(posilek);
        }

        public void DodajWszystkiePosilki(List<Posilek> listaPosilkow)
        {
            if (listaPosilkow == null)
            {
                throw new ArgumentNullException(nameof(listaPosilkow), "Lista posiłków nie może być null.");
            }
            Posilki.AddRange(listaPosilkow);
        }

        public bool UsunPosilek(DateTime data)
        {
            var posilekDoUsuniecia = Posilki.FirstOrDefault(p => p.Data.Equals(data));

            if (posilekDoUsuniecia != null)
            {
                Posilki.Remove(posilekDoUsuniecia);
                return true;
            }
            return false;
        }


        public bool AktualizujPosilek(DateTime data, string nazwa, double kalorie, DateTime nowaData)
        {
            var posilekDoAktualizacji = Posilki.FirstOrDefault(p => p.Data.Equals(data));
            if (posilekDoAktualizacji != null)
            {
                posilekDoAktualizacji.Nazwa = nazwa;
                posilekDoAktualizacji.Kalorie = kalorie;
                posilekDoAktualizacji.Data = nowaData;
                return true;
            }
            return false;
        }
    }
}
