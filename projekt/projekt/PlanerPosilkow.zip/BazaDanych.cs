﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanerPosilkow
{
    public class BazaDanych
    {
        private const string FilePath = "db.txt";
        private PlanPosilkow planPosilkow;

        public BazaDanych(PlanPosilkow plan)
        {
            planPosilkow = plan ?? throw new ArgumentNullException(nameof(plan), "Plan posiłków nie może być null.");
        }

        public void ZapiszDane()
        {
            using (StreamWriter writer = new StreamWriter(FilePath))
            {
                foreach (var posilek in planPosilkow.Posilki)
                {
                    // Zapisujemy datę bez milisekund
                    writer.WriteLine($"{posilek.Nazwa};{posilek.GetType().Name};{posilek.Kalorie};{posilek.Data:dd-MM-yyyy HH:mm:ss}");
                }
            }
        }

        public void OdczytajDane()
        {
            if (!File.Exists(FilePath))
                return;

            List<Posilek> wczytanePosilki = new List<Posilek>();

            using (StreamReader reader = new StreamReader(FilePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var dane = line.Split(';');
                    if (dane.Length == 4 && double.TryParse(dane[2], out double kalorie)&& DateTime.TryParseExact(
                            dane[3], "dd-MM-yyyy HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out DateTime data))
                    {
                        // Przycina milisekundy w odczytanej dacie
                        data = data.AddMilliseconds(-data.Millisecond);

                        switch (dane[1])
                        {
                            case "Sniadanie":
                                wczytanePosilki.Add(new Sniadanie(dane[0], kalorie, data));
                                break;
                            case "Obiad":
                                wczytanePosilki.Add(new Obiad(dane[0], kalorie, data));
                                break;
                            case "Przekaska":
                                wczytanePosilki.Add(new Przekaska(dane[0], kalorie, data));
                                break;
                            case "Kolacja":
                                wczytanePosilki.Add(new Kolacja(dane[0], kalorie, data));
                                break;
                        }
                    }
                }
            }

            planPosilkow.DodajWszystkiePosilki(wczytanePosilki);
        }
    }
}
